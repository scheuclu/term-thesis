A Pen created at CodePen.io. You can find this one at http://codepen.io/leecrossley/pen/CBHca.

 A name (first name and surname) is input and a canvas element is output using the initials from the name and a background colour (based on the first name first letter). The background colours are from from http://flatuicolors.com/
Now with retina support.